
import React, { useState } from 'react';
import { useAppContext } from '../hooks/useAppContext';
import { User, UserRole, Certificate } from '../types';
import { UserAddIcon, ChevronDownIcon, AcademicCapIcon, PlusCircleIcon, TrashIcon, PencilIcon, CheckCircleIcon, ShieldExclamationIcon } from './icons';
import Modal from './common/Modal';

// Certificate Configuration Rules
const CERT_TYPES = [
    { id: 'wah', label: 'Working at Heights', expiryYears: 3, hasRefresher: true },
    { id: 'supervisor', label: "Supervisors' Health and Safety Awareness in 5 Steps", expiryYears: 0 }, // 0 = No Expiry
    { id: 'worker', label: "Workers' Health and Safety Awareness in 4 Steps", expiryYears: 0 },
    { id: 'whmis', label: 'WHMIS 2015 Instruction', expiryYears: 1 },
    { id: 'firstaid', label: 'First Aid Training', expiryYears: 3, hasDetails: true, detailLabel: 'Type (e.g., Standard, CPR, AED)' },
    { id: 'other', label: 'Other / Custom', expiryYears: 0, isCustom: true }
];

const UserManagementView: React.FC = () => {
  const { users, updateUser, addUser, deleteUser, addCertificate, updateCertificate, deleteCertificate } = useAppContext();
  const [expandedUserId, setExpandedUserId] = useState<number | null>(null);
  
  // Add User State
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState<UserRole>('consultant');
  const [newUserTitle, setNewUserTitle] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserPassword, setNewUserPassword] = useState('');

  // Edit User State (Temporary state for inputs while editing)
  const [editingUser, setEditingUser] = useState<Partial<User>>({});

  // Certificate State
  const [isAddingCert, setIsAddingCert] = useState(false);
  const [newCertData, setNewCertData] = useState<Partial<Certificate>>({});
  const [selectedCertType, setSelectedCertType] = useState(CERT_TYPES[0].id);

  const handleAddUser = async (e: React.FormEvent) => {
      e.preventDefault();
      if(newUserName && newUserEmail && newUserPassword) {
          await addUser(newUserName, newUserEmail, newUserRole, newUserPassword, newUserTitle, newUserPhone);
          setIsAddingUser(false);
          setNewUserName('');
          setNewUserEmail('');
          setNewUserRole('consultant');
          setNewUserTitle('');
          setNewUserPhone('');
          setNewUserPassword('');
      }
  };

  const startEditingUser = (user: User) => {
      setEditingUser({ name: user.name, email: user.email, role: user.role, phone: user.phone, title: user.title });
  };

  const saveUserChanges = async (userId: number) => {
      await updateUser(userId, editingUser);
      setEditingUser({});
  };

  const handleDeleteUser = async (userId: number, userName: string) => {
      if (window.confirm(`Are you sure you want to delete ${userName}? This will unassign all their sites and remove their history. This action cannot be undone.`)) {
          await deleteUser(userId);
          if (expandedUserId === userId) setExpandedUserId(null);
      }
  };

  // ... Certificate logic ...
  const handleCertSubmit = async (userId: number) => {
      if (newCertData.name && newCertData.issueDate) {
          await addCertificate(userId, newCertData as Omit<Certificate, 'id'>);
          setIsAddingCert(false);
          setNewCertData({});
      }
  };

  const handleDeleteCertificate = async (userId: number, certId: string) => {
      if(window.confirm("Delete this certificate?")) {
          await deleteCertificate(userId, certId);
      }
  };

  // Helper to render date status
  const getCertStatus = (cert: Certificate) => {
      if (!cert.expiryDate) return { color: 'text-green-600', icon: CheckCircleIcon, text: 'Valid (No Expiry)' };
      const expiry = new Date(cert.expiryDate);
      const today = new Date();
      const diffDays = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      
      if (diffDays < 0) return { color: 'text-red-600', icon: ShieldExclamationIcon, text: `Expired (${Math.abs(diffDays)} days ago)` };
      if (diffDays < 30) return { color: 'text-yellow-600', icon: ShieldExclamationIcon, text: `Expiring soon (${diffDays} days)` };
      return { color: 'text-green-600', icon: CheckCircleIcon, text: 'Valid' };
  };

  const inputClasses = "block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-white";

  return (
      <div className="space-y-6">
          <div className="flex items-center justify-between">
              <div>
                  <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-100">User Management</h2>
                  <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">Manage consultants, roles, and certifications.</p>
              </div>
              <button onClick={() => setIsAddingUser(true)} className="flex items-center px-4 py-2 text-sm font-bold text-white rounded-md bg-brand-primary hover:bg-brand-secondary">
                  <UserAddIcon className="w-5 h-5 mr-2" /> Add User
              </button>
          </div>

          {/* User List */}
          <div className="space-y-4">
              {users.map(user => {
                  const isExpanded = expandedUserId === user.id;
                  const isEditingThisUser = editingUser.name !== undefined && isExpanded; // Simple check if editing

                  return (
                      <div key={user.id} className="bg-white border rounded-lg shadow-sm dark:bg-gray-800 dark:border-gray-700 overflow-hidden">
                          <div 
                              className="p-4 flex items-center justify-between cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors"
                              onClick={() => {
                                  setExpandedUserId(isExpanded ? null : user.id);
                                  setEditingUser({}); // Reset edit state on toggle
                                  setIsAddingCert(false);
                              }}
                          >
                              <div className="flex items-center space-x-4">
                                  <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg ${user.role === 'management' ? 'bg-purple-600' : 'bg-brand-secondary'}`}>
                                      {user.name.charAt(0)}
                                  </div>
                                  <div>
                                      <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100">{user.name}</h3>
                                      <div className="text-sm text-gray-600 dark:text-gray-400 flex flex-col">
                                          <span>{user.email}</span>
                                          <div className="flex items-center flex-wrap gap-x-2">
                                              <span className="font-medium text-gray-800 dark:text-gray-300">
                                                  {user.title || <span className="capitalize">{user.role}</span>}
                                              </span>
                                              {user.phone && (
                                                  <>
                                                      <span className="text-gray-300 dark:text-gray-600">•</span>
                                                      <span>{user.phone}</span>
                                                  </>
                                              )}
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <div className="flex items-center">
                                  {user.certificates && user.certificates.length > 0 && (
                                      <span className="mr-4 text-xs px-2 py-1 bg-green-100 text-green-800 rounded-full dark:bg-green-900/30 dark:text-green-300 hidden sm:inline-block">
                                          {user.certificates.length} Certs
                                      </span>
                                  )}
                                  <ChevronDownIcon className={`w-5 h-5 text-gray-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                              </div>
                          </div>

                          {/* Expanded Details */}
                          {isExpanded && (
                              <div className="p-6 border-t bg-gray-50 dark:bg-gray-900/30 dark:border-gray-700">
                                  
                                  {/* Profile Edit Section */}
                                  <div className="mb-8">
                                      <div className="flex justify-between items-center mb-4">
                                          <h4 className="text-md font-bold text-gray-800 dark:text-gray-200 uppercase tracking-wide">Profile Details</h4>
                                          {!isEditingThisUser && (
                                              <div className="flex space-x-2">
                                                  <button onClick={(e) => { e.stopPropagation(); startEditingUser(user); }} className="text-sm text-brand-primary hover:underline flex items-center">
                                                      <PencilIcon className="w-4 h-4 mr-1" /> Edit Profile
                                                  </button>
                                                  <button onClick={(e) => { e.stopPropagation(); handleDeleteUser(user.id, user.name); }} className="text-sm text-red-600 hover:underline flex items-center ml-4">
                                                      <TrashIcon className="w-4 h-4 mr-1" /> Delete User
                                                  </button>
                                              </div>
                                          )}
                                      </div>

                                      {isEditingThisUser ? (
                                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-4 rounded border dark:bg-gray-800 dark:border-gray-600">
                                              <div>
                                                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400">Full Name</label>
                                                  <input type="text" value={editingUser.name || ''} onChange={e => setEditingUser({...editingUser, name: e.target.value})} className={inputClasses} />
                                              </div>
                                              <div>
                                                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400">Email</label>
                                                  <input type="email" value={editingUser.email || ''} onChange={e => setEditingUser({...editingUser, email: e.target.value})} className={inputClasses} />
                                              </div>
                                              <div>
                                                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400">Job Title</label>
                                                  <input type="text" value={editingUser.title || ''} onChange={e => setEditingUser({...editingUser, title: e.target.value})} className={inputClasses} placeholder="e.g. Senior Consultant" />
                                              </div>
                                              <div>
                                                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400">Phone</label>
                                                  <input type="tel" value={editingUser.phone || ''} onChange={e => setEditingUser({...editingUser, phone: e.target.value})} className={inputClasses} />
                                              </div>
                                              <div>
                                                  <label className="block text-xs font-medium text-gray-500 dark:text-gray-400">Role</label>
                                                  <select value={editingUser.role || 'consultant'} onChange={e => setEditingUser({...editingUser, role: e.target.value as UserRole})} className={inputClasses}>
                                                      <option value="consultant">Consultant</option>
                                                      <option value="management">Management</option>
                                                  </select>
                                              </div>
                                              <div className="flex items-end space-x-2">
                                                  <button onClick={() => saveUserChanges(user.id)} className="px-3 py-2 bg-brand-primary text-white rounded text-sm hover:bg-brand-secondary">Save Changes</button>
                                                  <button onClick={() => setEditingUser({})} className="px-3 py-2 bg-gray-200 text-gray-700 rounded text-sm hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-300">Cancel</button>
                                              </div>
                                          </div>
                                      ) : null}
                                  </div>

                                  {/* Certificates Section */}
                                  <div>
                                      <div className="flex justify-between items-center mb-4">
                                          <h4 className="text-md font-bold text-gray-800 dark:text-gray-200 uppercase tracking-wide">Certifications & Training</h4>
                                          <button onClick={() => setIsAddingCert(!isAddingCert)} className="text-sm text-green-600 hover:text-green-700 flex items-center">
                                              <PlusCircleIcon className="w-4 h-4 mr-1" /> Add Certificate
                                          </button>
                                      </div>

                                      {isAddingCert && (
                                          <div className="mb-4 p-4 bg-green-50 rounded border border-green-200 dark:bg-green-900/10 dark:border-green-800">
                                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                  <div className="md:col-span-2">
                                                      <label className="block text-xs font-medium text-gray-700 dark:text-gray-300">Training Type</label>
                                                      <select 
                                                          value={selectedCertType} 
                                                          onChange={e => {
                                                              const typeId = e.target.value;
                                                              const typeDef = CERT_TYPES.find(t => t.id === typeId);
                                                              setSelectedCertType(typeId);
                                                              setNewCertData({ 
                                                                  name: typeDef?.label || '',
                                                                  issueDate: '',
                                                                  expiryDate: '',
                                                                  notes: ''
                                                              });
                                                          }} 
                                                          className={inputClasses}
                                                      >
                                                          {CERT_TYPES.map(t => <option key={t.id} value={t.id}>{t.label}</option>)}
                                                      </select>
                                                  </div>
                                                  {selectedCertType === 'other' && (
                                                      <div className="md:col-span-2">
                                                          <label className="block text-xs font-medium text-gray-700 dark:text-gray-300">Certificate Name</label>
                                                          <input type="text" value={newCertData.name || ''} onChange={e => setNewCertData({...newCertData, name: e.target.value})} className={inputClasses} placeholder="Enter certificate name" />
                                                      </div>
                                                  )}
                                                  <div>
                                                      <label className="block text-xs font-medium text-gray-700 dark:text-gray-300">Issue Date</label>
                                                      <input type="date" value={newCertData.issueDate || ''} onChange={e => setNewCertData({...newCertData, issueDate: e.target.value})} className={inputClasses} />
                                                  </div>
                                                  <div>
                                                      <label className="block text-xs font-medium text-gray-700 dark:text-gray-300">Expiry Date (Optional)</label>
                                                      <input type="date" value={newCertData.expiryDate || ''} onChange={e => setNewCertData({...newCertData, expiryDate: e.target.value})} className={inputClasses} />
                                                  </div>
                                                  <div className="md:col-span-2">
                                                      <label className="block text-xs font-medium text-gray-700 dark:text-gray-300">Notes / ID Number</label>
                                                      <input type="text" value={newCertData.notes || ''} onChange={e => setNewCertData({...newCertData, notes: e.target.value})} className={inputClasses} placeholder="e.g. License #12345" />
                                                  </div>
                                              </div>
                                              <div className="mt-3 flex justify-end space-x-2">
                                                  <button onClick={() => setIsAddingCert(false)} className="px-3 py-1.5 text-xs text-gray-600 hover:bg-gray-100 rounded">Cancel</button>
                                                  <button onClick={() => handleCertSubmit(user.id)} className="px-3 py-1.5 text-xs bg-green-600 text-white rounded hover:bg-green-700">Save Certificate</button>
                                              </div>
                                          </div>
                                      )}

                                      <div className="space-y-3">
                                          {user.certificates && user.certificates.length > 0 ? (
                                              user.certificates.map(cert => {
                                                  const status = getCertStatus(cert);
                                                  const StatusIcon = status.icon;
                                                  return (
                                                      <div key={cert.id} className="flex items-center justify-between p-3 bg-white border rounded shadow-sm dark:bg-gray-800 dark:border-gray-600">
                                                          <div className="flex items-start space-x-3">
                                                              <div className="mt-1"><AcademicCapIcon className="w-5 h-5 text-gray-400" /></div>
                                                              <div>
                                                                  <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">{cert.name}</p>
                                                                  <p className="text-xs text-gray-500 dark:text-gray-400">
                                                                      Issued: {cert.issueDate} {cert.expiryDate && `• Expires: ${cert.expiryDate}`}
                                                                  </p>
                                                                  {cert.notes && <p className="text-xs text-gray-400 italic mt-0.5">{cert.notes}</p>}
                                                                  <div className={`flex items-center mt-1 text-xs font-medium ${status.color}`}>
                                                                      <StatusIcon className="w-3 h-3 mr-1" />
                                                                      {status.text}
                                                                  </div>
                                                              </div>
                                                          </div>
                                                          <button onClick={() => handleDeleteCertificate(user.id, cert.id)} className="text-gray-400 hover:text-red-500 transition-colors" title="Delete Certificate">
                                                              <TrashIcon className="w-4 h-4" />
                                                          </button>
                                                      </div>
                                                  );
                                              })
                                          ) : (
                                              <p className="text-sm text-gray-500 italic">No certificates recorded.</p>
                                          )}
                                      </div>
                                  </div>
                              </div>
                          )}
                      </div>
                  );
              })}
          </div>

          {/* Add User Modal */}
          {isAddingUser && (
              <Modal isOpen={true} onClose={() => setIsAddingUser(false)} title="Add New User">
                  <form onSubmit={handleAddUser} className="space-y-4">
                      <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Full Name</label>
                          <input type="text" value={newUserName} onChange={e => setNewUserName(e.target.value)} className={inputClasses} required />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                          <input type="email" value={newUserEmail} onChange={e => setNewUserEmail(e.target.value)} className={inputClasses} required />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Job Title</label>
                          <input type="text" value={newUserTitle} onChange={e => setNewUserTitle(e.target.value)} className={inputClasses} placeholder="e.g. Safety Consultant" />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Phone Number</label>
                          <input type="tel" value={newUserPhone} onChange={e => setNewUserPhone(e.target.value)} className={inputClasses} placeholder="(555) 123-4567" />
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">System Role</label>
                          <select value={newUserRole} onChange={e => setNewUserRole(e.target.value as UserRole)} className={inputClasses}>
                              <option value="consultant">Consultant</option>
                              <option value="management">Management</option>
                          </select>
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Initial Password</label>
                          <input type="text" value={newUserPassword} onChange={e => setNewUserPassword(e.target.value)} className={inputClasses} placeholder="e.g. TempPass123" required />
                          <p className="text-xs text-gray-500 mt-1">This will be the password the user uses to log in for the first time.</p>
                      </div>
                      <div className="flex justify-end pt-4 space-x-3">
                          <button type="button" onClick={() => setIsAddingUser(false)} className="px-4 py-2 text-sm text-gray-700 bg-gray-100 rounded-md hover:bg-gray-200">Cancel</button>
                          <button type="submit" className="px-4 py-2 text-sm text-white bg-brand-primary rounded-md hover:bg-brand-secondary">Create User</button>
                      </div>
                  </form>
              </Modal>
          )}
      </div>
  );
};

export default UserManagementView;
