
export type Theme = 'light' | 'dark' | 'system';

export type UserRole = 'consultant' | 'management';

export interface Certificate {
  id: string;
  name: string;
  issueDate: string;
  expiryDate?: string;
  notes?: string;
}

export interface User {
  id: number;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  title?: string;
  certificates?: Certificate[];
  password?: string;
}

export type VisitFrequency = 'Weekly' | 'Bi-Weekly' | 'Monthly' | 'Shop Audit';

export type SiteStatus = 'Active' | 'Not Active' | 'On Hold' | 'Completed';

export interface Contact {
  role: string;
  name: string;
  info: string;
}

export type BillingStatus = 'processed' | 'not_processed';

export interface Site {
  id: number;
  clientName: string;
  address: string;
  frequency: VisitFrequency;
  assignedConsultantId: number;
  status: SiteStatus;
  lastVisited?: string;
  notes?: string;
  isPriority?: boolean;
  priorityNote?: string;
  siteGroupId?: string;
  clientType: string;
  scopeOfWork: string;
  contacts: Contact[];
  city: string; 
  latitude: number;
  longitude: number;
  initialVisitRequestor?: string;
  
  // On Hold Logic
  onHoldReason?: string;
  onHoldStart?: string;
  onHoldEnd?: string;
  onHoldSetBy?: number;
  onHoldUpdatedAt?: string;
  onHoldApprovalStatus?: 'Pending' | 'Approved';

  // Billing Logic
  billingStatus?: BillingStatus;
  billingStatusUpdatedAt?: string;
  billingStatusUpdatedBy?: number;

  // Link to another site (for shared locations)
  linkToSiteId?: number | null;
}

export type ReportStatus = 'Visit Complete' | 'Site Not Active' | 'Client Cancelled' | 'Project Finished' | 'On Hold' | 'Revisit Waived';

export type ProcedureType = 'SWP' | 'JHA';

export interface DeliveredItems {
    greenBooks?: number;
    safetyBoard?: number;
    fireExtinguisher?: number;
    eyeWashStation?: number;
    firstAidKitSmall?: number;
    firstAidKitLarge?: number;
    inspectionTags?: number;
    specificProcedure?: number;
}

export interface ReportDocument {
    id: string;
    name: string;
    type: string;
    data: string;
    uploadedAt: string;
}

export interface Report {
    id: string;
    siteId: number;
    consultantId: number;
    visitDate: string;
    status: ReportStatus;
    notes?: string;
    managementNotes?: string;
    reviewStatus: 'pending' | 'approved' | 'rejected';
    proceduresCreated: ProcedureType[];
    documents: ReportDocument[];
    deliveredItems?: DeliveredItems;
}

export interface Procedure {
    id: string;
    description: string;
    type: ProcedureType;
    status: 'Ongoing' | 'Completed';
    siteId: number;
    consultantId: number;
    createdAt: string;
    fileUrl?: string;
}

export type BulletinCategory = 'Company Update' | 'Health & Safety' | 'General';
export type BulletinPriority = 'Normal' | 'High';

export interface BulletinItem {
    id: string;
    title: string;
    content: string;
    category: BulletinCategory;
    priority: BulletinPriority;
    createdAt: string;
    createdBy: number;
    acknowledgments: { userId: number; timestamp: string }[];
}

export type NavigationTarget = {
    view: 'management' | 'consultant';
    tab?: string;
    siteId?: number;
};

export interface Announcement {
    id: number;
    message: string;
    createdAt: string;
    targetUserId?: number;
    requiresAcknowledgment?: boolean;
    type?: 'general' | 'banner' | 'critical';
    isAcknowledged: boolean;
    acknowledgedAt?: string;
    navTarget?: NavigationTarget;
}

export type ComplaintStatus = 'Open' | 'Under Review' | 'Resolved';

export interface Complaint {
    id: string;
    userId: number;
    siteId?: number;
    notes: string;
    date: string;
    status: ComplaintStatus;
    managementNotes?: string;
}

export type IncentiveStatus = 'Pending' | 'Approved' | 'Paid';
export type IncentiveType = 'Lump Sum' | 'Percentage' | 'Recurring' | 'Other';
export type IncentiveCategory = 'New Client' | 'Client Expansion' | 'Referral' | 'Performance' | 'Other';

export interface Incentive {
    id: string;
    userId: number;
    amount: number;
    description: string;
    status: IncentiveStatus;
    incentiveType: IncentiveType;
    category: IncentiveCategory;
    date: string;
    notes?: string;
}

export type ActionType = 'Status Change' | 'Report Filed' | 'Plan Update' | 'Hold Request' | 'Undo Action' | 'Edit Report' | 'Remove Site' | 'Billing Update' | 'Edit Profile';

export interface ActionLog {
    id: string;
    userId: number;
    userName: string;
    actionType: ActionType;
    details: string;
    siteName?: string;
    timestamp: string;
    documents?: { name: string; data: string }[];
}

export interface VisitActivity {
    id: string;
    consultantId: number;
    siteId: number;
    date: string;
    lastActivityAt: string;
    status: 'in_progress' | 'completed';
}

export type Weekday = 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';

export interface WeeklyPlan {
    todo: Site[];
    planned: Record<Weekday, Site[]>;
}

export type WeeklyPlanState = Record<number, WeeklyPlan>;

export type ToastMessage = {
    id: number;
    message: string;
    type: 'success' | 'error' | 'info';
    navTarget?: NavigationTarget;
};

export interface RouteOptimizationConfig {
    travelTimeRate: number;
    distanceRate: number;
    perSiteRate: number;
    avgSpeedKmh: number;
    maxDailyDriveTime: number;
    maxDailyDistance: number;
}

export type RouteMode = 'fastest' | 'balanced';

export interface RouteSuggestion {
    mode: RouteMode;
    orderedSites: Site[];
    totalDistance: number;
    totalTime: number;
    estimatedPay: {
        timePay: number;
        distancePay: number;
        sitePay: number;
        total: number;
    };
    costPerSite: number;
    warnings: string[];
}

export interface PlanGenerationOptions {
    targetUserIds: number[];
    includeUnassigned: boolean;
    cityFilter: string;
    frequencyFilter: VisitFrequency | 'all';
    maxSitesPerUser: number;
}

export interface AppContextType {
    user: User | null;
    users: User[];
    sites: Site[];
    reports: Report[];
    procedures: Procedure[];
    announcements: Announcement[];
    complaints: Complaint[];
    incentives: Incentive[];
    actionLogs: ActionLog[];
    bulletinItems: BulletinItem[];
    visitActivities: VisitActivity[];
    weeklyPlans: WeeklyPlanState;
    toasts: ToastMessage[];
    theme: Theme;
    isLoading: boolean;
    error: string | null;
    routeConfig: RouteOptimizationConfig;
    routeSuggestions: RouteSuggestion | null;
    draftWeeklyPlans: WeeklyPlanState | null;
    lastImportedSiteIds: number[] | null;
    pendingNavigation: NavigationTarget | null;

    login: (email: string, password: string) => boolean;
    logout: () => void;
    register: (name: string, email: string, password: string, role: UserRole) => void;
    setTheme: (theme: Theme) => void;
    addToast: (message: string, type?: ToastMessage['type'], navTarget?: NavigationTarget) => void;
    
    addReport: (reportData: any) => Promise<void>;
    updateReport: (reportId: string, updates: Partial<Report>) => Promise<void>;
    deleteReport: (reportId: string) => Promise<void>;
    
    addSite: (siteData: Omit<Site, 'id'>) => Promise<boolean>;
    addSites: (sitesData: Omit<Site, 'id'>[]) => Promise<{ added: number, skipped: number }>;
    updateSite: (siteId: number, updates: Partial<Site>) => Promise<void>;
    updateSiteBillingStatus: (siteId: number, status: BillingStatus) => Promise<void>;
    reassignSites: (siteIds: number[], newConsultantId: number) => Promise<void>;
    requestSiteHold: (siteId: number, reason: string, start: string, end: string) => Promise<void>;
    resolveHoldRequest: (siteId: number, approved: boolean) => Promise<void>;
    clearSiteHold: (siteId: number) => Promise<void>;
    undoLastImport: () => Promise<void>;

    updateProcedure: (procedureId: string, updates: Partial<Procedure>) => Promise<void>;
    addProcedure: (procedureData: any) => Promise<void>;

    addUser: (name: string, email: string, role: UserRole, password?: string, title?: string, phone?: string) => Promise<void>;
    updateUser: (userId: number, updates: Partial<User>) => Promise<void>;
    deleteUser: (userId: number) => Promise<void>;
    addCertificate: (userId: number, certificate: Omit<Certificate, 'id'>) => Promise<void>;
    updateCertificate: (userId: number, certId: string, updates: Partial<Certificate>) => Promise<void>;
    deleteCertificate: (userId: number, certId: string) => Promise<void>;

    addAnnouncement: (message: string, targetUserId?: number, requiresAcknowledgment?: boolean, type?: 'general' | 'banner' | 'critical', navTarget?: NavigationTarget) => Promise<void>;
    broadcastBanner: (message: string) => Promise<void>;
    acknowledgeAnnouncement: (announcementId: number) => Promise<void>;

    addComplaint: (userId: number, notes: string, siteId?: number) => Promise<void>;
    updateComplaint: (complaintId: string, updates: Partial<Complaint>) => Promise<void>;

    addIncentive: (incentive: Omit<Incentive, 'id'>) => Promise<void>;
    updateIncentive: (id: string, updates: Partial<Incentive>) => Promise<void>;

    addBulletinItem: (item: Omit<BulletinItem, 'id' | 'createdAt' | 'acknowledgments'>) => Promise<void>;
    updateBulletinItem: (id: string, updates: Partial<BulletinItem>) => Promise<void>;
    deleteBulletinItem: (id: string) => Promise<void>;
    acknowledgeBulletinItem: (id: string) => Promise<void>;

    updateWeeklyPlan: (consultantId: number, plan: WeeklyPlan) => void;
    generateNextWeeksPlans: (options: PlanGenerationOptions) => Promise<void>;
    confirmDraftPlans: (editedPlans: WeeklyPlanState) => void;
    clearDraftPlans: () => void;

    updateRouteConfig: (newConfig: Partial<RouteOptimizationConfig>) => Promise<void>;
    generateRouteSuggestions: (consultantId: number, day: Weekday, mode: RouteMode) => Promise<void>;
    clearRouteSuggestions: () => void;

    approveChange: (reportId: string) => Promise<void>;
    rejectChange: (reportId: string) => Promise<void>;

    setPendingNavigation: (target: NavigationTarget | null) => void;
    clearPendingNavigation: () => void;

    logVisitActivity: (siteId: number) => Promise<void>;
    resetAppData: () => void;
}
