
import { User, Site, Report, Procedure, Announcement, Complaint, Incentive, BulletinItem, VisitActivity } from '../types';

// Helper functions for date generation
const daysAgo = (days: number) => {
    const d = new Date();
    d.setDate(d.getDate() - days);
    return d.toISOString().split('T')[0];
};

const daysFromNow = (days: number) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    return d.toISOString().split('T')[0];
};

// Constant for simulating a recent Friday
export const RECENT_FRIDAY = daysAgo((new Date().getDay() + 2) % 7 + (new Date().getDay() === 5 ? 0 : 0));

// --- 1. USERS ---
export const USERS: User[] = [
  { 
      id: 1, 
      name: 'Alice Johnson', 
      email: 'alice@gmg.com', 
      role: 'consultant', 
      title: 'Senior Safety Consultant',
      phone: '416-555-0101',
      password: 'password123',
      certificates: [
          { id: 'cert-1', name: 'Working at Heights (Refresher)', issueDate: daysAgo(365), expiryDate: daysFromNow(730), notes: 'Ministry approved' },
          { id: 'cert-2', name: 'First Aid - Standard Level C', issueDate: daysAgo(400), expiryDate: daysFromNow(600) },
          { id: 'cert-3', name: 'WHMIS 2015', issueDate: daysAgo(100), expiryDate: daysFromNow(265) }
      ]
  },
  { 
      id: 2, 
      name: 'Bob Williams', 
      email: 'bob@gmg.com', 
      role: 'consultant', 
      title: 'Safety Consultant',
      phone: '905-555-0102',
      password: 'password123',
      certificates: [
          { id: 'cert-5', name: 'WHMIS 2015', issueDate: daysAgo(400), expiryDate: daysAgo(35), notes: 'EXPIRED: Needs immediate renewal' }, // Expired
          { id: 'cert-8', name: 'Working at Heights', issueDate: daysAgo(1100), expiryDate: daysAgo(5), notes: 'Expired last week' }, // Expired
          { id: 'cert-9', name: 'First Aid - Standard Level C', issueDate: daysAgo(1080), expiryDate: daysFromNow(10) } // Expiring Soon
      ]
  },
  { id: 3, name: 'Charlie Davis', email: 'charlie@gmg.com', role: 'management', title: 'Operations Manager', phone: '416-555-0103', password: 'password123' },
  { 
      id: 4, 
      name: 'David Miller', 
      email: 'david@gmg.com', 
      role: 'consultant', 
      title: 'Field Technician',
      phone: '519-555-0104',
      password: 'password123',
      certificates: [
          { id: 'cert-10', name: 'Working at Heights', issueDate: daysAgo(200), expiryDate: daysFromNow(895) },
          { id: 'cert-11', name: 'Traffic Control (Book 7)', issueDate: daysAgo(400), expiryDate: daysAgo(1), notes: 'Just Expired' }
      ] 
  },
  {
      id: 5,
      name: 'Sarah Connor',
      email: 'sarah@gmg.com',
      role: 'consultant',
      title: 'Junior Consultant',
      phone: '647-555-9876',
      password: 'password123',
      certificates: [
          { id: 'cert-12', name: 'Joint Health and Safety Committee Part 1', issueDate: daysAgo(60), expiryDate: '' },
          { id: 'cert-13', name: 'Working at Heights', issueDate: daysAgo(10), expiryDate: daysFromNow(1085) }
      ]
  }
];

// --- 2. MOCK DATA PLACEHOLDERS ---
// Providing initial empty arrays or basic data to ensure application loads without errors if full data is missing.
export const SITES: Site[] = [
    {
        id: 101,
        clientName: "Acme Construction",
        address: "123 Main St",
        city: "Toronto",
        frequency: "Weekly",
        assignedConsultantId: 1,
        status: "Active",
        clientType: "General Contractor",
        scopeOfWork: "Weekly inspections",
        contacts: [],
        latitude: 43.65,
        longitude: -79.38
    }
]; 
export const REPORTS: Report[] = [];
export const PROCEDURES: Procedure[] = [];
export const ANNOUNCEMENTS: Announcement[] = [];
export const COMPLAINTS: Complaint[] = [];
export const INCENTIVES: Incentive[] = [];
export const BULLETIN_ITEMS: BulletinItem[] = [];
export const VISIT_ACTIVITIES: VisitActivity[] = [];
