
import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { 
    User, Site, Report, Procedure, Announcement, Complaint, Incentive, ActionLog, BulletinItem, 
    VisitActivity, WeeklyPlanState, ToastMessage, Theme, NavigationTarget, AppContextType, 
    RouteOptimizationConfig, RouteSuggestion, PlanGenerationOptions, UserRole, Certificate, BillingStatus,
    WeeklyPlan
} from '../types';
import { USERS, SITES, REPORTS, PROCEDURES, ANNOUNCEMENTS, COMPLAINTS, INCENTIVES, BULLETIN_ITEMS } from '../data/mockData';
import { safeLocalStorage } from '../utils/storage';

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<User | null>(null);
    
    // Initialize users from LocalStorage if available, otherwise use MOCK data.
    const [users, setUsers] = useState<User[]>(() => {
        const storedUsers = safeLocalStorage.getItem('users', null);
        return storedUsers ? storedUsers : USERS;
    });

    // Persist users to local storage whenever they change
    useEffect(() => {
        safeLocalStorage.setItem('users', users);
    }, [users]);

    const [sites, setSites] = useState<Site[]>(SITES || []);
    const [reports, setReports] = useState<Report[]>(REPORTS || []);
    const [procedures, setProcedures] = useState<Procedure[]>(PROCEDURES || []);
    const [announcements, setAnnouncements] = useState<Announcement[]>(ANNOUNCEMENTS || []);
    const [complaints, setComplaints] = useState<Complaint[]>(COMPLAINTS || []);
    const [incentives, setIncentives] = useState<Incentive[]>(INCENTIVES || []);
    const [actionLogs, setActionLogs] = useState<ActionLog[]>([]);
    const [bulletinItems, setBulletinItems] = useState<BulletinItem[]>(BULLETIN_ITEMS || []);
    const [visitActivities, setVisitActivities] = useState<VisitActivity[]>([]);
    const [weeklyPlans, setWeeklyPlans] = useState<WeeklyPlanState>({});
    const [toasts, setToasts] = useState<ToastMessage[]>([]);
    const [theme, setTheme] = useState<Theme>('system');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    
    const [routeConfig, setRouteConfig] = useState<RouteOptimizationConfig>({
        travelTimeRate: 25,
        distanceRate: 0.55,
        perSiteRate: 50,
        avgSpeedKmh: 60,
        maxDailyDriveTime: 8,
        maxDailyDistance: 400
    });
    const [routeSuggestions, setRouteSuggestions] = useState<RouteSuggestion | null>(null);
    const [draftWeeklyPlans, setDraftWeeklyPlans] = useState<WeeklyPlanState | null>(null);
    const [lastImportedSiteIds, setLastImportedSiteIds] = useState<number[] | null>(null);
    const [pendingNavigation, setPendingNavigation] = useState<NavigationTarget | null>(null);

    const addToast = useCallback((message: string, type: ToastMessage['type'] = 'info', navTarget?: NavigationTarget) => {
        const id = Date.now();
        setToasts(prev => [...prev, { id, message, type, navTarget }]);
        setTimeout(() => setToasts(prev => prev.filter(t => t.id !== id)), 5000);
    }, []);

    const logAction = useCallback((actionType: any, details: string) => {
        if (!user) return;
        const newLog: ActionLog = {
            id: Date.now().toString(),
            userId: user.id,
            userName: user.name,
            actionType,
            details,
            timestamp: new Date().toISOString()
        };
        setActionLogs(prev => [newLog, ...prev]);
    }, [user]);

    const withLoading = useCallback(async (fn: () => Promise<void>) => {
        setIsLoading(true);
        try {
            await fn();
        } catch (e: any) {
            setError(e.message);
            addToast(e.message, 'error');
        } finally {
            setIsLoading(false);
        }
    }, [addToast]);

    // Login/Logout
    const login = (email: string, password: string): boolean => {
        // Simple simulation of authentication
        const found = users.find(u => u.email.toLowerCase() === email.toLowerCase());
        if (found) {
            // Check password (if one exists in mock data, otherwise allow generic login for dev)
            if (found.password && found.password !== password) {
                addToast('Invalid password', 'error');
                return false;
            }
            setUser(found);
            addToast(`Welcome back, ${found.name}`);
            return true;
        }
        addToast('User not found', 'error');
        return false;
    };

    const register = (name: string, email: string, password: string, role: UserRole) => {
        const newUser: User = {
            id: Date.now(),
            name,
            email,
            role,
            password, // Store password locally for this simulation
            certificates: []
        };
        setUsers(prev => [...prev, newUser]);
        setUser(newUser); // Auto-login
        addToast(`Account created for ${name}`, 'success');
    };

    const logout = () => setUser(null);

    // Implementations matching AppContextType...
    const addReport = useCallback(async (reportData: any) => {
        if (!user) return;
        await withLoading(async () => {
            const newReport = { ...reportData, id: Date.now().toString(), consultantId: user.id, reviewStatus: 'pending' };
            setReports(prev => [...prev, newReport]);
            logAction('Report Filed', `Filed report for site ${reportData.siteId}`);
            addToast('Report submitted successfully', 'success');
        });
    }, [user, withLoading, logAction, addToast]);

    const updateReport = useCallback(async (reportId: string, updates: Partial<Report>) => {
        await withLoading(async () => {
            setReports(prev => prev.map(r => r.id === reportId ? { ...r, ...updates } : r));
            logAction('Edit Report', `Updated report ${reportId}`);
            addToast('Report updated');
        });
    }, [withLoading, logAction, addToast]);

    const deleteReport = useCallback(async (reportId: string) => {
        setReports(prev => prev.filter(r => r.id !== reportId));
        logAction('Undo Action', `Deleted report ${reportId}`);
        addToast('Report deleted');
    }, [logAction, addToast]);

    const addSite = useCallback(async (siteData: Omit<Site, 'id'>) => {
        const newId = Date.now();
        const newSite = { ...siteData, id: newId };
        setSites(prev => [...prev, newSite as Site]);
        logAction('Status Change', `Added site ${siteData.clientName}`);
        addToast('Site added');
        return true;
    }, [logAction, addToast]);

    const addSites = useCallback(async (newSitesData: Omit<Site, 'id'>[]) => {
        const added: Site[] = [];
        let skippedCount = 0;
        
        setSites(prev => {
            const existingNames = new Set(prev.map(s => s.clientName.toLowerCase()));
            const nextSites = [...prev];
            newSitesData.forEach(s => {
                if (!existingNames.has(s.clientName.toLowerCase())) {
                    const newSite = { ...s, id: Math.floor(Math.random() * 1000000) }; // Simple random ID
                    nextSites.push(newSite as Site);
                    added.push(newSite as Site);
                } else {
                    skippedCount++;
                }
            });
            return nextSites;
        });
        
        setLastImportedSiteIds(added.map(s => s.id));
        return { added: added.length, skipped: skippedCount };
    }, []);

    const updateSite = useCallback(async (siteId: number, updates: any) => {
        setSites(prev => prev.map(s => s.id === siteId ? { ...s, ...updates } : s));
        logAction('Status Change', `Updated site ${siteId}`);
        addToast('Site updated');
    }, [logAction, addToast]);

    const updateSiteBillingStatus = useCallback(async (siteId: number, status: BillingStatus) => {
        if (!user) return;
        setSites(prev => prev.map(s => s.id === siteId ? { 
            ...s, 
            billingStatus: status,
            billingStatusUpdatedAt: new Date().toISOString(),
            billingStatusUpdatedBy: user.id 
        } : s));
        logAction('Billing Update', `Updated billing status for site ${siteId} to ${status}`);
    }, [user, logAction]);

    const reassignSites = useCallback(async (siteIds: number[], newConsultantId: number) => {
        setSites(prev => prev.map(s => siteIds.includes(s.id) ? { ...s, assignedConsultantId: newConsultantId } : s));
        logAction('Plan Update', `Reassigned ${siteIds.length} sites`);
        addToast('Sites reassigned');
    }, [logAction, addToast]);

    const requestSiteHold = useCallback(async (siteId: number, reason: string, start: string, end: string) => {
        if (!user) return;
        setSites(prev => prev.map(s => s.id === siteId ? {
            ...s,
            status: 'On Hold',
            onHoldReason: reason,
            onHoldStart: start,
            onHoldEnd: end,
            onHoldSetBy: user.id,
            onHoldUpdatedAt: new Date().toISOString(),
            onHoldApprovalStatus: user.role === 'management' ? 'Approved' : 'Pending'
        } : s));
        logAction('Hold Request', `Requested hold for site ${siteId}`);
        addToast('Hold request submitted');
    }, [user, logAction, addToast]);

    const resolveHoldRequest = useCallback(async (siteId: number, approved: boolean) => {
        setSites(prev => prev.map(s => s.id === siteId ? {
            ...s,
            onHoldApprovalStatus: approved ? 'Approved' : 'Pending', 
            status: approved ? 'On Hold' : 'Active'
        } : s));
        addToast(`Hold request ${approved ? 'approved' : 'rejected'}`);
    }, [addToast]);

    const clearSiteHold = useCallback(async (siteId: number) => {
        setSites(prev => prev.map(s => s.id === siteId ? {
            ...s,
            status: 'Active',
            onHoldReason: undefined,
            onHoldStart: undefined,
            onHoldEnd: undefined
        } : s));
        addToast('Site hold cleared');
    }, [addToast]);

    const updateProcedure = useCallback(async (procedureId: string, updates: Partial<Procedure>) => {
        setProcedures(prev => prev.map(p => p.id === procedureId ? { ...p, ...updates } : p));
        addToast('Procedure updated');
    }, [addToast]);

    const addUser = useCallback(async (name: string, email: string, role: UserRole, password?: string, title?: string, phone?: string) => {
        const newUser: User = {
            id: Date.now(),
            name,
            email,
            role,
            password: password || '123456',
            title,
            phone,
            certificates: []
        };
        setUsers(prev => [...prev, newUser]);
        logAction('Status Change', `Added user ${name}`);
        addToast('User added successfully');
    }, [logAction, addToast]);

    const updateUser = useCallback(async (userId: number, updates: any) => {
        setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
        addToast('User updated');
    }, [addToast]);

    const deleteUser = useCallback(async (userId: number) => {
        setUsers(prev => prev.filter(u => u.id !== userId));
        // Unassign sites
        setSites(prev => prev.map(s => s.assignedConsultantId === userId ? { ...s, assignedConsultantId: 0 } : s));
        addToast('User deleted');
    }, [addToast]);

    const addCertificate = useCallback(async (userId: number, certificate: Omit<Certificate, 'id'>) => {
        const newCert = { ...certificate, id: Date.now().toString() };
        setUsers(prev => prev.map(u => u.id === userId ? { ...u, certificates: [...(u.certificates || []), newCert] } : u));
        addToast('Certificate added');
    }, [addToast]);

    const updateCertificate = useCallback(async (userId: number, certId: string, updates: Partial<Certificate>) => {
        setUsers(prev => prev.map(u => {
            if (u.id !== userId) return u;
            return {
                ...u,
                certificates: u.certificates?.map(c => c.id === certId ? { ...c, ...updates } : c)
            };
        }));
        addToast('Certificate updated');
    }, [addToast]);

    const deleteCertificate = useCallback(async (userId: number, certId: string) => {
        setUsers(prev => prev.map(u => {
            if (u.id !== userId) return u;
            return { ...u, certificates: u.certificates?.filter(c => c.id !== certId) };
        }));
        addToast('Certificate deleted');
    }, [addToast]);

    const addProcedure = useCallback(async (procedureData: any) => {
        if (!user) return;
        const newProc = { ...procedureData, id: Date.now().toString(), consultantId: user.id, createdAt: new Date().toISOString() };
        setProcedures(prev => [...prev, newProc]);
        addToast('Procedure created');
    }, [user, addToast]);

    const addAnnouncement = useCallback(async (message: string, targetUserId?: number, requiresAcknowledgment?: boolean, type: any = 'general', navTarget?: NavigationTarget) => {
        const newAnn = {
            id: Date.now(),
            message,
            createdAt: new Date().toISOString(),
            targetUserId,
            requiresAcknowledgment,
            type,
            navTarget,
            isAcknowledged: false
        };
        setAnnouncements(prev => [newAnn, ...prev]);
    }, []);

    const broadcastBanner = useCallback(async (message: string) => {
        await addAnnouncement(message, undefined, true, 'banner');
        addToast('Banner broadcasted');
    }, [addAnnouncement, addToast]);

    const acknowledgeAnnouncement = useCallback(async (announcementId: number) => {
        setAnnouncements(prev => prev.map(a => a.id === announcementId ? { ...a, isAcknowledged: true, acknowledgedAt: new Date().toISOString() } : a));
    }, []);

    const addComplaint = useCallback(async (userId: number, notes: string, siteId?: number) => {
        const newComplaint: Complaint = {
            id: Date.now().toString(),
            userId,
            notes,
            siteId,
            date: new Date().toISOString(),
            status: 'Open'
        };
        setComplaints(prev => [newComplaint, ...prev]);
        addToast('Complaint logged');
    }, [addToast]);

    const updateComplaint = useCallback(async (complaintId: string, updates: any) => {
        setComplaints(prev => prev.map(c => c.id === complaintId ? { ...c, ...updates } : c));
        addToast('Complaint updated');
    }, [addToast]);

    const addIncentive = useCallback(async (incentive: Omit<Incentive, 'id'>) => {
        setIncentives(prev => [...prev, { ...incentive, id: Date.now().toString() }]);
        addToast('Incentive added');
    }, [addToast]);

    const updateIncentive = useCallback(async (id: string, updates: Partial<Incentive>) => {
        setIncentives(prev => prev.map(i => i.id === id ? { ...i, ...updates } : i));
        addToast('Incentive updated');
    }, [addToast]);

    const addBulletinItem = useCallback(async (item: any) => {
        if (!user) return;
        const newItem = { ...item, id: Date.now().toString(), createdAt: new Date().toISOString(), createdBy: user.id, acknowledgments: [] };
        setBulletinItems(prev => [newItem, ...prev]);
        addToast('Notice posted');
    }, [user, addToast]);

    const updateBulletinItem = useCallback(async (id: string, updates: any) => {
        setBulletinItems(prev => prev.map(b => b.id === id ? { ...b, ...updates } : b));
        addToast('Notice updated');
    }, [addToast]);

    const deleteBulletinItem = useCallback(async (id: string) => {
        setBulletinItems(prev => prev.filter(b => b.id !== id));
        addToast('Notice deleted');
    }, [addToast]);

    const acknowledgeBulletinItem = useCallback(async (id: string) => {
        if (!user) return;
        setBulletinItems(prev => prev.map(b => b.id === id ? { 
            ...b, 
            acknowledgments: [...b.acknowledgments, { userId: user.id, timestamp: new Date().toISOString() }] 
        } : b));
    }, [user]);

    const updateWeeklyPlan = useCallback((consultantId: number, plan: WeeklyPlan) => {
        setWeeklyPlans(prev => ({ ...prev, [consultantId]: plan }));
    }, []);

    const approveChange = useCallback(async (reportId: string) => {
        setReports(prev => prev.map(r => r.id === reportId ? { ...r, reviewStatus: 'approved' } : r));
        addToast('Report approved');
    }, [addToast]);

    const rejectChange = useCallback(async (reportId: string) => {
        setReports(prev => prev.map(r => r.id === reportId ? { ...r, reviewStatus: 'rejected' } : r));
        addToast('Report rejected');
    }, [addToast]);

    const generateNextWeeksPlans = useCallback(async (options: PlanGenerationOptions) => {
        // Mock AI generation logic
        addToast('Generating plans... (Simulation)', 'info');
        setTimeout(() => {
            addToast('Plans generated and saved as draft.');
            // Create a mock draft plan
            const draft: WeeklyPlanState = {};
            options.targetUserIds.forEach(uid => {
                // Just distribute random sites for now
                const userSites = sites.filter(s => s.assignedConsultantId === uid && s.status === 'Active');
                draft[uid] = {
                    todo: userSites,
                    planned: { Monday: [], Tuesday: [], Wednesday: [], Thursday: [], Friday: [] }
                };
            });
            setDraftWeeklyPlans(draft);
        }, 1000);
    }, [sites, addToast]);

    const updateRouteConfig = useCallback(async (newConfig: Partial<RouteOptimizationConfig>) => {
        setRouteConfig(prev => ({ ...prev, ...newConfig }));
        addToast('Route settings updated');
    }, [addToast]);

    const generateRouteSuggestions = useCallback(async (consultantId: number, day: any, mode: any) => {
        addToast('Calculating route...');
        // This usually calls the routing utility, here we just mock a suggestion or rely on the view to call util
        setRouteSuggestions({
            mode,
            orderedSites: [],
            totalDistance: 120,
            totalTime: 4.5,
            estimatedPay: { timePay: 100, distancePay: 60, sitePay: 200, total: 360 },
            costPerSite: 45,
            warnings: []
        });
    }, [addToast]);

    const clearRouteSuggestions = useCallback(() => setRouteSuggestions(null), []);

    const confirmDraftPlans = useCallback((editedPlans: WeeklyPlanState) => {
        setWeeklyPlans(prev => ({ ...prev, ...editedPlans }));
        setDraftWeeklyPlans(null);
        addToast('Weekly plans confirmed and published', 'success');
    }, [addToast]);

    const clearDraftPlans = useCallback(() => setDraftWeeklyPlans(null), []);

    const undoLastImport = useCallback(async () => {
        if (!lastImportedSiteIds) return;
        setSites(prev => prev.filter(s => !lastImportedSiteIds.includes(s.id)));
        setLastImportedSiteIds(null);
        addToast('Last import undone');
    }, [lastImportedSiteIds, addToast]);

    const clearPendingNavigation = useCallback(() => setPendingNavigation(null), []);

    const logVisitActivity = useCallback(async (siteId: number) => {
        if (!user) return;
        const now = new Date().toISOString();
        setVisitActivities(prev => {
            // update existing activity for today or add new
            const today = now.split('T')[0];
            const existing = prev.find(a => a.consultantId === user.id && a.siteId === siteId && a.date === today);
            if (existing) {
                return prev.map(a => a === existing ? { ...a, lastActivityAt: now } : a);
            }
            return [...prev, {
                id: Date.now().toString(),
                consultantId: user.id,
                siteId,
                date: today,
                lastActivityAt: now,
                status: 'in_progress'
            }];
        });
    }, [user]);

    const resetAppData = useCallback(() => {
        setUsers(USERS);
        setSites(SITES);
        setReports(REPORTS);
        setProcedures(PROCEDURES);
        setAnnouncements(ANNOUNCEMENTS);
        setComplaints(COMPLAINTS);
        setIncentives(INCENTIVES);
        setBulletinItems(BULLETIN_ITEMS);
        safeLocalStorage.removeItem('users');
        addToast('Data reset');
    }, [addToast]);

    return (
        <AppContext.Provider value={{
            user, users, sites, reports, procedures, announcements, complaints, incentives, actionLogs, bulletinItems, visitActivities,
            login, logout, register,
            addReport, updateReport, deleteReport,
            addSite, addSites, updateSite, updateSiteBillingStatus, reassignSites, requestSiteHold, resolveHoldRequest, clearSiteHold,
            updateProcedure,
            addUser, updateUser, deleteUser,
            addCertificate, updateCertificate, deleteCertificate,
            addProcedure,
            addAnnouncement, broadcastBanner, acknowledgeAnnouncement,
            addComplaint, updateComplaint,
            addIncentive, updateIncentive,
            addBulletinItem, updateBulletinItem, deleteBulletinItem, acknowledgeBulletinItem,
            weeklyPlans, updateWeeklyPlan,
            isLoading, error,
            toasts, addToast,
            theme, setTheme,
            approveChange, rejectChange,
            generateNextWeeksPlans,
            routeConfig, updateRouteConfig, routeSuggestions, generateRouteSuggestions, clearRouteSuggestions,
            draftWeeklyPlans, confirmDraftPlans, clearDraftPlans,
            lastImportedSiteIds, undoLastImport,
            pendingNavigation, setPendingNavigation, clearPendingNavigation,
            logVisitActivity,
            resetAppData
        }}>
            {children}
        </AppContext.Provider>
    );
};

export const useAppContext = () => {
    const context = useContext(AppContext);
    if (context === undefined) {
        throw new Error('useAppContext must be used within an AppProvider');
    }
    return context;
};
